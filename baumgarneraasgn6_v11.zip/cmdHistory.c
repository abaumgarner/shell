#include "cmdHistory.h"

void printCMDHistory(void * passedIn, int index)
{
	CMDHistory * temp = (CMDHistory *)passedIn;
	
	printf("%d %s\n", index, temp -> cmd);
}

void printToFile(void * passedIn, FILE* fout)
{
	CMDHistory * temp = (CMDHistory *)passedIn;
	
	fprintf(fout, "%s\n",temp -> cmd);
}

void * buildCMDHistory(FILE * fin)
{
	char str[MAX];
	char *result;
	CMDHistory * cmdHist = (CMDHistory *)malloc(sizeof(CMDHistory));
	
	fgets(str, MAX, fin);
	
	strip(str);
	
	result = (char *)malloc((strlen(str)+1) * sizeof(char));
	strncpy((char*) result, str, strlen(str));
	cmdHist -> cmd = result;
	
	return (void *)cmdHist;
}

void cleanCMDHistory(void * hist)
{
	free(((CMDHistory*)hist)->cmd);
	free((CMDHistory*)hist);
}
