#include "utility.h"
#include "history.h"
// add your #includes here

int main()
{
    char s[MAX];		

	// You will need code to open .ushrc and .ush_history here
	FILE * ushrc = openFile(".ushrc", "r");
	FILE * ush_hist = openFile(".ush_history", "r");
	
	History * hist = setCounts(ushrc);
		
	printf("\nHistCount: %d\nHistFileCount: %d\n", hist -> histCount, hist -> histFileCount);
	
	printf("?: ");
	fgets(s, MAX, stdin);
	strip(s);

	while(strcmp(s, "exit") != 0)
	{

		// You will need fork it and pipe it and other code here
		
		
		

		// you will probably need code to clean up stuff

        printf("?: ");
        fgets(s, MAX, stdin);
        strip(s);

	}// end while
	
	close(ushrc);
	close(ush_hist);
	
	return 0;

}// end main
