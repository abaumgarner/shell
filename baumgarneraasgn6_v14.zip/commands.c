#include "commands.h"

void determinCommand(char * str, LinkedList * histList, History* hist, LinkedList* aliasList)
{
	regex_t pipeRegex, redirRegex, histRegex, redirRegex2;
	int pipeReti, redirReti, histReti, redirReti2;
	
	if(strcmp(str, "history") == 0)
	{
		if(histList -> size != 0)
		{
			printListFromIndex(histList, hist->histCount, printCMDHistory);
		}
		else
			printf("No history found\n");
	}
	else
	{
		if(strcmp(str, "!!") == 0)
		{

			 determinCommand(((CMDHistory*)histList -> tail -> data) -> cmd, histList, hist, aliasList);
		}
		else 
		{
			histReti = regcomp(&histRegex, "\\![1-9]+", REG_EXTENDED);
			histReti = regexec(&histRegex, str, 0, NULL, 0);
			
			if(!histReti)
			{
				int index;
				char * saveptr;
				char * token;
				Node* temp;
				
				token=strtok_r(str, "!", &saveptr);
				index = atoi(token);
				
				if(index <= histList -> size)
				{
					temp = getAtIndex(histList,index);
					determinCommand(((CMDHistory*)temp -> data) -> cmd, histList, hist, aliasList);
				}
				else
					printf("Command not found.\n");
				
			}
			else
			{
				pipeReti = regcomp(&pipeRegex, "\\|+", REG_EXTENDED);
				pipeReti = regexec(&pipeRegex, str, 0, NULL, 0);
				
				if(!pipeReti)
				{
					pipeCommand(str);
				}
				else
				{
					redirReti = regcomp(&redirRegex, "[\\>+]", REG_EXTENDED);
					redirReti = regexec(&redirRegex, str, 0, NULL, 0);
					
					if(!redirReti)
					{
						redirCommand(str);
					}
					else
					{
						redirReti2 = regcomp(&redirRegex2, "[\\<+]", REG_EXTENDED);
						redirReti2 = regexec(&redirRegex2, str, 0, NULL, 0);
						if(!redirReti2)
						{
							redirCommand2(str);
						}
						else
						{
							standardCommand(str);
						}
						regfree(&redirRegex2);
					}
					regfree(&redirRegex);
				}
				regfree(&pipeRegex);
			}
			regfree(&histRegex);
		}
	}
}

void redirCommand(char * str)
{	
	//system(str);
	char * token, *savePtr;
	char ** argv;
	int argc;
	
	int res;
	int status;
	pid_t pid = fork();
	
	token = strtok_r(str, ">", &savePtr);
	argv = makeargs(token, &argc);
	
	token = strtok_r(NULL, ">", &savePtr);
	int fd = open(token, O_RDWR | O_CREAT, S_IRUSR | S_IWUSR);
	
	if(pid != 0)
	{
		waitpid(pid, &status, 0);
		return;
	}
	else
	{
		dup2(fd, 1);
		res = execvp(*argv, argv);
		close(fd);
		
		if(res == -1)
		{
			printf("Command not found.\n");
			
			exit(1);
		}
	}
}

void redirCommand2(char * str)
{	
	//system(str);
	char * token, *savePtr;
	char ** argv;
	int argc;
	
	int res;
	int status;
	pid_t pid = fork();
	
	token = strtok_r(str, "<", &savePtr);
	argv = makeargs(token, &argc);
	
	token = strtok_r(NULL, "<", &savePtr);
	int fd = open(token, O_RDWR | O_CREAT, S_IRUSR | S_IWUSR);
	
	if(pid != 0)
	{
		waitpid(pid, &status, 0);
		return;
	}
	else
	{
		dup2(fd, 0);
		res = execvp(*argv, argv);
		close(fd);
		
		if(res == -1)
		{
			printf("Command not found.\n");
			
			exit(1);
		}
	}
}

void pipeCommand(char * str)
{
	int preCount = 0, postCount = 0;
	char ** prePipe = NULL, ** postPipe = NULL;
	
	prePipe = parsePrePipe(str, &preCount);
	postPipe = parsePostPipe(str, &postCount);
	
	pipeIt(prePipe, postPipe);

    clean(preCount, prePipe);
    clean(postCount, postPipe);
	
}

void standardCommand(char * str)
{
	char **argv = NULL;
	int argc;
	
	argv = makeargs(str, &argc);
	if(argv != NULL)
	{
		forkIt(argv);
	}
	
	clean(argc, argv);
}


