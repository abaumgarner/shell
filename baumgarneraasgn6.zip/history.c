#include "history.h"


void * setCounts(FILE * fin)
{
	char str[MAX];
	char * savePt;
	char * token;
	History * hist = (History *)malloc(sizeof(History));
	
	hist -> histCount = 100;
	hist -> histFileCount = 1000;
	
	if(fin != NULL)
	{
		fgets(str, MAX, fin);
		
		if(!feof(fin))
		{
			strip(str);
			
			token = strtok_r(str, "=", &savePt);
			
			if(strcmp(token, "HISTCOUNT") == 0)
			{				
				token = strtok_r(NULL, "=", &savePt);
				hist -> histCount = atoi(token);
			}
			else if(strcmp(token, "HISTFILECOUNT") == 0)
			{
				token = strtok_r(NULL, "=", &savePt);
				hist -> histFileCount = atoi(token);
			}
			
			fgets(str, MAX, fin);
			
			strip(str);
			
			if(!feof(fin))
			{
				token = strtok_r(str, "=", &savePt);
				if(strcmp(token, "HISTCOUNT") == 0)
				{
					token = strtok_r(NULL, "=", &savePt);
					hist -> histCount = atoi(token);
				}
				else if(strcmp(token, "HISTFILECOUNT") == 0)
				{
					token = strtok_r(NULL, "=", &savePt);
					hist -> histFileCount = atoi(token);
				}
			}
		}	
	}
	
	return hist;
}
