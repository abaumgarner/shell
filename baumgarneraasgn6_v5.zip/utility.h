#ifndef UTILITY_H
#define UTILITY_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define MAX 100

FILE * openFile(char * fname, char * type);
void strip(char *s);
void clean(int argc, char **argv);
void printargs(int argc, char **argv);
char ** makeargs(char *s, int * argc);
void forkIt(char ** argv);

#endif
