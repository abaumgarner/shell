/*
 * Aaorn Baumgarner
 * 
 */

#include "utility.h"

FILE * openFile(char * fname, char * type)
{
	FILE * fin=NULL;

	fin=fopen(fname,type);
	
	return fin;
}

void strip(char *s)
{
	int x = 0;
	while(x < MAX && s[x] != '\0')
	{
		if(s[x] == '\r')
			s[x] = '\0';

		else if(s[x] == '\n')
			s[x] = '\0';

		x++;
	}
}

void clean(int argc, char **argv)
{
	int i;
	
	for(i = 0; i < argc; i++)
	{
		free(argv[i]);
	}
	free(argv);
}

void printargs(int argc, char **argv)
{
	int x;
	for(x = 0; x < argc; x++)
		printf("%s", argv[x]);
	printf("\n");
}

char ** makeargs(char *s, int * argc)
{
	char * saveptr;
	int i = 0;
	*argc = 0;
	char * token;
	char * temp = (char*)calloc((strlen(s)+1), sizeof(char));
	strcpy(temp, s);
	
	token = strtok_r(temp, " \t", &saveptr);
	
	while(token != NULL)
	{
		(*argc)++;
		token = strtok_r(NULL, " \t", &saveptr);
	}	
	
	char ** ara = malloc(((*argc)+1) * sizeof(char*));
	
	strcpy(temp, s);
	token = strtok_r(temp, " \t", &saveptr);
	
	while(token != NULL)
	{		
		ara[i] = (char*)calloc(strlen(token)+1, sizeof(char));
		strcpy(ara[i], token);
		i++;
		
		token = strtok_r(NULL, " \t", &saveptr);
	}

	free(token);
	free(temp);
	
	ara[i] = '\0';

	return ara;
}

void forkIt(char ** argv)
{
	int res;
	int status;
	pid_t pid = fork();
	
	if(pid != 0)
	{
		waitpid(pid, &status, 0);
		return;
	}
	else
	{
		res = execvp(*argv, argv);
		
		if(res == -1)
		{
			printf("Command not found.\n");
			
			exit(1);
		}
	}

}
