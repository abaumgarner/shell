#ifndef COMMANDS_H
#define COMMANDS_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <regex.h>

void determinCommand(char *);
void pipeCommand(char *);
void pipeIt(char ** prePipe, char ** postPipe);
char ** parsePrePipe(char * s, int * count);
char ** parsePostPipe(char * s, int * count);
void standardCommand(char *);

#endif
