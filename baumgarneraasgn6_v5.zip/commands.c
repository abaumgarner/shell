#include "commands.h"
#include "utility.h"

void determinCommand(char * str)
{
	regex_t regex;
	int reti;
	
	reti = regcomp(&regex, "\\|+", REG_EXTENDED);
	
	reti = regexec(&regex, str, 0, NULL, 0);
	
	if(!reti)
	{
		pipeCommand(str);
	}
	else
		standardCommand(str);
		
	regfree(&regex);
}

void pipeCommand(char * str)
{
	int preCount = 0, postCount = 0;
	char ** prePipe = NULL, ** postPipe = NULL;
	
	prePipe = parsePrePipe(str, &preCount);
	postPipe = parsePostPipe(str, &postCount);
	
	pipeIt(prePipe, postPipe);

    clean(preCount, prePipe);
    clean(postCount, postPipe);
	
}

void pipeIt(char ** prePipe, char ** postPipe)
{
	pid_t pid, pid2;
	int fd[2], res, status;
	int exeRes;
	
	pid2 = fork();
	
	if(pid2 != 0)
	{
		waitpid(pid2, &status, 0);
		return;
	}
	else
	{
	
		res = pipe(fd);

		if(res < 0)
		{
			printf("Pipe Failure\n");
			exit(-1);
		}// end if

		pid = fork();
		
		if(pid == 0)
		{
			close(fd[0]); 
			close(1); 
			dup(fd[1]); 
			close(fd[1]); 
			
			exeRes = execlp(prePipe[0],prePipe[0],prePipe[1], NULL);
			
			if(exeRes == -1)
			{			
				exit(1);
			}
		}
		else
		{
			close(fd[1]); 
			close(0); 
			dup(fd[0]); 
			close(fd[0]); 
			
			exeRes = execlp(postPipe[0],postPipe[0],postPipe[1], NULL);
			
			if(exeRes == -1)
			{
				printf("Invalid command.\n");			
				exit(1);
			}
		}
	}
}

char ** parsePrePipe(char * s, int * count)
{
	char * saveptr;
	char * token;
	char * temp = (char*)calloc((strlen(s)), sizeof(char));
	strcpy(temp, s);
	
	token = strtok_r(temp, "|", &saveptr);
	free(temp);
	return makeargs(token, count);
}

char ** parsePostPipe(char * s, int * count)
{
	char * saveptr;
	char * token;
	char * temp = (char*)calloc((strlen(s)), sizeof(char));
	strcpy(temp, s);
	
	token = strtok_r(temp, "|", &saveptr);
	token = strtok_r(NULL, "|", &saveptr);	
	free(temp);
	
	return makeargs(token, count);
}

void standardCommand(char * str)
{
	char **argv = NULL;
	int argc;
	
	argv = makeargs(str, &argc);
	if(argv != NULL)
	{
		forkIt(argv);
	}
	
	clean(argc, argv);
}
