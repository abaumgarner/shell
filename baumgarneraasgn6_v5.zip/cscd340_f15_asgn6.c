
#include "utility.h"
#include "history.h"
#include "commands.h"

// add your #includes here

int main()
{
    char s[MAX];		

	// You will need code to open .ushrc and .ush_history here
	FILE * ushrc = openFile(".ushrc", "r");
	FILE * ush_hist = openFile(".ush_history", "r");
	
	History * hist = setCounts(ushrc);
		
	printf("\nHistCount: %d\nHistFileCount: %d\n", hist -> histCount, hist -> histFileCount);
	
	printf("?: ");
	fgets(s, MAX, stdin);
	strip(s);

	while(strcmp(s, "exit") != 0)
	{

		// You will need fork it and pipe it and other code here
		determinCommand(s);
		//standardCommand(s);
		
		
		// you will probably need code to clean up stuff

        printf("?: ");
        fgets(s, MAX, stdin);
        strip(s);

	}// end while
	
	if(ushrc != NULL)
		fclose(ushrc);
	
	if(ush_hist != NULL)
		fclose(ush_hist);
	
	cleanHistory(hist);
	
	return 0;

}// end main
