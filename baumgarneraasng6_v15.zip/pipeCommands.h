#ifndef PIPECOMMANDS_H
#define PIPECOMMANDS_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include "utility.h"

void pipeIt(char ** prePipe, char ** postPipe);

#endif // PIPECOMMANDS_h
