/*
 * Aaron Baumgarner
 * Notes:
 * 	History doesn't keep track of commands as you type them. However, it is wired up to save the list to the file.
 * 	Alias kind of works. It looks through the file and counts the number of alias in file but does not pull them from the file correctly.
 * 	The basic forms of normal commands, pipes, redirects. But if you combine a pipe with a redirect it does not work.
 * 	
 */
#include "utility.h"
#include "history.h"
#include "commands.h"
#include "cmdHistory.h"
#include "linkedList.h"
#include "alias.h"
// add your #includes here

int main()
{
    char s[MAX];		

	// You will need code to open .ushrc and .ush_history here
	FILE * ushrc = openFile(".ushrc", "r");
	FILE * ush_hist = openFile(".ush_history", "r");
	History * hist = histObj();
	
	if(ushrc != NULL)
		setCounts(ushrc, hist);
	int total;
	LinkedList * cmdHist = linkedList();
	LinkedList * aliasList = linkedList();
	if(ush_hist != NULL)
	{
		total = countRecords(ush_hist, 1);
		if(total != 0)
			buildList(cmdHist, ush_hist, total, buildCMDHistory);
	}
	
	if(ushrc != NULL)
	{
		total = countAlias(ushrc, 1);
		if(total != 0)
		{
			buildList(aliasList, ushrc, total, buildAlias);
		}
		//printList(aliasList, printAlias);
	}
	//Stu's..no touchy
	printf("?: ");
	fgets(s, MAX, stdin);
	strip(s);

	while(strcmp(s, "exit") != 0)
	{
		// You will need fork it and pipe it and other code here
		
		determinCommand(s, cmdHist, hist, aliasList);
		
		
		// you will probably need code to clean up stuff
		
		//Stu's..no touchy
        printf("?: ");
        fgets(s, MAX, stdin);
        strip(s);
        
        if(strcmp(s, "exit") == 0)
        {
			if(ush_hist == NULL)
				ush_hist = openFile(".ush_history", "w");
			saveToFile(cmdHist, hist->histFileCount, ush_hist, printToFile);
		}

	}// end while
	
	if(ushrc != NULL)
		fclose(ushrc);
	
	if(ush_hist != NULL)
		fclose(ush_hist);
	if(cmdHist != NULL)
	{
		clearList(cmdHist, cleanCMDHistory);
		free(cmdHist);
		cmdHist = NULL;
	}
	
	if(aliasList != NULL)
	{
		clearList(aliasList, cleanAlias);
		free(aliasList);
		aliasList = NULL;
	}
	
	cleanHistory(hist);

	return 0;

}// end main
