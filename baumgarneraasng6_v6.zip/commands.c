#include "commands.h"

void determinCommand(char * str)
{
	regex_t regex;
	int reti;
	
	reti = regcomp(&regex, "\\|+", REG_EXTENDED);
	
	reti = regexec(&regex, str, 0, NULL, 0);
	
	if(!reti)
	{
		pipeCommand(str);
	}
	else
		standardCommand(str);
		
	regfree(&regex);
}

void pipeCommand(char * str)
{
	int preCount = 0, postCount = 0;
	char ** prePipe = NULL, ** postPipe = NULL;
	
	prePipe = parsePrePipe(str, &preCount);
	postPipe = parsePostPipe(str, &postCount);
	
	pipeIt(prePipe, postPipe);

    clean(preCount, prePipe);
    clean(postCount, postPipe);
	
}

void standardCommand(char * str)
{
	char **argv = NULL;
	int argc;
	
	argv = makeargs(str, &argc);
	if(argv != NULL)
	{
		forkIt(argv);
	}
	
	clean(argc, argv);
}
