/*
 * Aaorn Baumgarner
 * 
 */

#include "alias.h"

void printAlias(void * passedIn)
{
	Alias * temp = (Alias *)passedIn;
	
	printf("alias %s=%s %s\n", temp -> aliasName, temp -> aliasCMD, temp -> aliasOptions);
}

int compareTwoAlias(const void * p1, const void * p2)
{
	Alias* alias1 = (Alias*)p1;
	Alias* alias2 = (Alias*) p2;
	return strcmp(alias1 -> aliasName, alias2 -> aliasName);
}

void cleanAlias(void * ali)
{
	free(((Alias*)ali)->aliasName);
	free(((Alias*)ali)->aliasCMD);
	free(((Alias*)ali)->aliasOptions);
	free((Alias*)ali);
}
