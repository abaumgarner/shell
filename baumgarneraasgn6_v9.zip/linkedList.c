/*
 * Aaron Baumgarner
 */
#include "linkedList.h"
#include "utility.h"


extern Node * head;
extern Node * tail;
extern int size;


LinkedList * linkedList()
{
	LinkedList * theList = (LinkedList *) malloc(sizeof(LinkedList));
	
	theList -> head = NULL;
	theList -> tail = NULL;
	theList -> size = 0;
	
	return theList;
}

Node * getAtIndex(LinkedList * theList, int index)
{
	int i;
	Node * temp, *cur = theList -> head;
	
	for(i = 1; i <= theList -> size; i++)
	{
		if(i == index)
		{
			temp = cur;
		}
		
		cur = cur -> next;
	}
	return temp;
}

void addFirst(LinkedList * theList, Node * newNode)
{	
	if(theList -> head==NULL)
	{
		theList -> head=newNode;
		theList -> tail=newNode;
	}

	else
	{
		newNode->next=theList -> head;
		theList -> head -> prev=newNode;
		theList -> head=newNode;
	}
	
	theList -> size = theList -> size + 1;
	
}
void addLast(LinkedList * theList, Node * newNode)
{	
	if(theList -> head==NULL)
		addFirst(theList, newNode);
	
	else
	{
		Node * cur=theList -> head;
		
		while(cur != NULL && cur -> next !=NULL)
		{
			cur=cur->next;
		}
		
		newNode -> prev=cur;
		cur -> next=newNode;
		theList -> tail = newNode;
		theList -> size = theList -> size + 1;
	}	
}

void printList(const LinkedList * theList, void (*convertData)(void *, int))
{
	int index = 1;
	
	if(theList -> head==NULL)
		printf("The list is empty.\n");
	
	else
	{
		Node * cur = theList -> head;
		
		while(cur != NULL)
		{
			void * curData = cur -> data;
			convertData(curData, index);
			cur = cur -> next;
			index++;
		}
		
	}
}//end printList

void removeItem(LinkedList * theList, Node * nn, void (*removeData)(void *), int (*compare)(const void *, const void *))
{
	Node * cur = theList -> head;
	
	while(compare(cur -> data, nn -> data) != 0 && cur -> next != NULL)
	{
		cur = cur -> next;
	}
	
	if(cur != NULL)
	{
		removeData(cur -> data);
		
		if(cur -> next != NULL)
		{
			cur -> next -> prev = cur -> prev;
		}
		cur -> prev -> next = cur -> next;
		
		theList -> size = theList -> size - 1;
	}
	free(cur);
	removeData(nn -> data);
	free(nn);
}

void clearList(LinkedList * theList, void (*removeData)(void *))
{
	if(theList -> head != NULL)
	{
		Node * cur=theList -> head;
		
		while(cur!=NULL)
		{
			theList -> head=theList -> head->next;
			removeData(cur->data);
			free(cur);
			cur=theList -> head;
			theList -> size = theList -> size -1;
		}	
	}
}

void sort(LinkedList * theList, int (*compare)(const void *, const void *))
{
	if(theList -> size <= 1)
	{
		printf("The list is sorted\n");
	}
	
	else
	{
		int swapped;
		Node * nodeOne = theList -> head;
		Node * nodeTwo = NULL;
		
		do
		{
			swapped = 0;
			nodeOne = theList -> head;
			
			while(nodeOne -> next != nodeTwo)
			{
				if(compare(nodeOne -> data, nodeOne -> next -> data) > 0)
				{
					void * temp = nodeOne -> data;
					nodeOne -> data = nodeOne -> next -> data;
					nodeOne -> next -> data = temp;
					swapped = 1;
				}
				nodeOne = nodeOne -> next;
			}
			nodeTwo = nodeOne;
		}while(swapped);

	}	
}

void buildList(LinkedList * myList, FILE * fin, int total, void * (*buildData)(FILE * in))
{
	int i;
	for(i = 0; i < total; i++)
	{
		addLast(myList, buildNode(fin,*buildData));
	}

}
