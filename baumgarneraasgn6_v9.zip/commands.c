#include "commands.h"

void determinCommand(char * str, LinkedList * histList)
{
	regex_t pipeRegex, redirRegex, histRegex;
	int pipeReti, redirReti, histReti;
	
	if(strcmp(str, "history") == 0)
	{
		if(histList -> size != 0)
		{
			printList(histList, printCMDHistory);
		}
		else
			printf("No history found\n");
	}
	else
	{
		if(strcmp(str, "!!") == 0)
		{

			 determinCommand(((CMDHistory*)histList -> tail -> data) -> cmd, histList);
		}
		else 
		{
			histReti = regcomp(&histRegex, "[\\!\\d]", REG_EXTENDED);
			histReti = regexec(&histRegex, str, 0, NULL, 0);
			
			if(!histReti)
			{
				int index;
				char * saveptr;
				char * token;
				Node* temp;
				
				token=strtok_r(str, "!", &saveptr);
				index = atoi(token);
				
				temp = getAtIndex(histList,index);
				
				determinCommand(((CMDHistory*)temp -> data) -> cmd, histList);
			}
			else
			{
				pipeReti = regcomp(&pipeRegex, "\\|+", REG_EXTENDED);
				pipeReti = regexec(&pipeRegex, str, 0, NULL, 0);
				
				if(!pipeReti)
				{
					pipeCommand(str);
				}
				else
				{
					redirReti = regcomp(&redirRegex, "[\\>+]", REG_EXTENDED);
					redirReti = regexec(&redirRegex, str, 0, NULL, 0);
					
					if(!redirReti)
					{
						printf("\n\nhas redir\n\n");
					}
					else
						standardCommand(str);
					regfree(&redirRegex);
				}
				regfree(&pipeRegex);
			}
			regfree(&histRegex);
		}
	}
}

void redirCommand(char * str)
{
	/*int preCount = 0, postCount = 0;
	char ** preRedir = NULL, ** postRedir = NULL;
	
	preRedir = parsePreRedir(str, &preCount);
	postRedir = parsePostRedir(str, &postCount);
	
	pipeIt(prePipe, postPipe);

    clean(preCount, prePipe);
    clean(postCount, postPipe);
    */
}

void pipeCommand(char * str)
{
	int preCount = 0, postCount = 0;
	char ** prePipe = NULL, ** postPipe = NULL;
	
	prePipe = parsePrePipe(str, &preCount);
	postPipe = parsePostPipe(str, &postCount);
	
	pipeIt(prePipe, postPipe);

    clean(preCount, prePipe);
    clean(postCount, postPipe);
	
}

void standardCommand(char * str)
{
	char **argv = NULL;
	int argc;
	
	argv = makeargs(str, &argc);
	if(argv != NULL)
	{
		forkIt(argv);
	}
	
	clean(argc, argv);
}


