/*
 * Aaorn Baumgarner
 * 
 */

#ifndef ALIAS_H
#define ALIAS_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct alias
{
	char * aliasName;
	char * aliasCMD;
	char * aliasOptions;
};
typedef struct alias Alias;

void printAlias(void * passedIn);
//void * buildAlias(FILE *);
int compareTwoAlias(const void * p1, const void * p2);
void cleanAlias(void *);

#endif
