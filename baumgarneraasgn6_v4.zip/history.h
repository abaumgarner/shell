/*
 * Aaorn Baumgarner
 * 
 */

#ifndef HISTORY_H
#define HISTORY_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "utility.h"

struct history
{
	int histCount;
	int histFileCount;
};
typedef struct history History;

void * setCounts(FILE * fin);

#endif
