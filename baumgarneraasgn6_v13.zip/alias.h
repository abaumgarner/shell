/*
 * Aaorn Baumgarner
 * 
 */

#ifndef ALIAS_H
#define ALIAS_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <regex.h>
#include "utility.h"

struct alias
{
	char * aliasName;
	char * aliasCMD;
};
typedef struct alias Alias;

void printAlias(void * passedIn, int);
void * buildAlias(FILE * fin);
int compareTwoAlias(const void * p1, const void * p2);
void cleanAlias(void *);
int compareTo(const void* p, char* str);

#endif
