#ifndef CMDHISTORY_H
#define CMDHISTORY_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "utility.h"

struct cmdHistory
{
	char * cmd;
};
typedef struct cmdHistory CMDHistory;

void printCMDHistory(void * passedIn, int index);
void printToFile(void * passedIn, FILE* fout);
void * buildCMDHistory(FILE * fin);
void cleanCMDHistory(void * hist);

#endif
