#include "commands.h"

void determinCommand(char * str, LinkedList * histList)
{
	regex_t pipeRegex, redirRegex;
	int pipeReti, redirReti;
	
	if(strcmp(str, "history") == 0)
	{
		if(histList -> size != 0)
		{
			printList(histList, printCMDHistory);
		}
		else
			printf("No history found\n");
	}
	else
	{
		pipeReti = regcomp(&pipeRegex, "\\|+", REG_EXTENDED);
		pipeReti = regexec(&pipeRegex, str, 0, NULL, 0);
		
		if(!pipeReti)
		{
			pipeCommand(str);
		}
		else
		{
			redirReti = regcomp(&redirRegex, "[\\>+]", REG_EXTENDED);
			redirReti = regexec(&redirRegex, str, 0, NULL, 0);
			
			if(!redirReti)
			{
				printf("\n\nhas redir\n\n");
			}
			else
				standardCommand(str);
		}
		regfree(&pipeRegex);
	}
	
}

void redirCommand(char * str)
{
	/*int preCount = 0, postCount = 0;
	char ** preRedir = NULL, ** postRedir = NULL;
	
	preRedir = parsePreRedir(str, &preCount);
	postRedir = parsePostRedir(str, &postCount);
	
	pipeIt(prePipe, postPipe);

    clean(preCount, prePipe);
    clean(postCount, postPipe);
    */
}

void pipeCommand(char * str)
{
	int preCount = 0, postCount = 0;
	char ** prePipe = NULL, ** postPipe = NULL;
	
	prePipe = parsePrePipe(str, &preCount);
	postPipe = parsePostPipe(str, &postCount);
	
	pipeIt(prePipe, postPipe);

    clean(preCount, prePipe);
    clean(postCount, postPipe);
	
}

void standardCommand(char * str)
{
	char **argv = NULL;
	int argc;
	
	argv = makeargs(str, &argc);
	if(argv != NULL)
	{
		forkIt(argv);
	}
	
	clean(argc, argv);
}


