#include "parseCommands.h"

//Left side of |
char ** parsePrePipe(char * s, int * count)
{
	char * saveptr;
	char * token;
	char * temp = (char*)calloc((strlen(s)), sizeof(char));
	strcpy(temp, s);
	
	token = strtok_r(temp, "|", &saveptr);
	//free(temp);
	return makeargs(token, count);
}


//right side of |
char ** parsePostPipe(char * s, int * count)
{
	char * saveptr;
	char * token;
	char * temp = (char*)calloc((strlen(s)), sizeof(char));
	strcpy(temp, s);
	
	token = strtok_r(temp, "|", &saveptr);
	token = strtok_r(NULL, "|", &saveptr);	
	//free(temp);
	
	return makeargs(token, count);
}
