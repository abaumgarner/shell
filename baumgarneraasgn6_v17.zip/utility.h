#ifndef UTILITY_H
#define UTILITY_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <regex.h>
#include "linkedList.h"
#include "cmdHistory.h"


#define MAX 100

FILE * openFile(char * fname, char * type);
void strip(char *s);
void clean(int argc, char **argv);
void printargs(int argc, char **argv);
char ** makeargs(char *s, int * argc);
void forkIt(char ** argv);
Node * buildNode(FILE * in, void *(*buildData)(FILE * in) );
Node * buildStrNode(char * str, void *(*buildData)(char * in) );
int countRecords(FILE * fin, int lines);
int countAlias(FILE * fin, int lines);

#endif
