#ifndef COMMANDS_H
#define COMMANDS_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <regex.h>
#include <unistd.h>
#include <fcntl.h>
#include "utility.h"
#include "pipeCommands.h"
#include "parseCommands.h"
#include "linkedList.h"
#include "history.h"
#include "alias.h"

void determinCommand(char *, LinkedList * list, History* hist, LinkedList* aliasList);
void pipeCommand(char *);
void pipeIt(char ** prePipe, char ** postPipe);
char ** parsePrePipe(char * s, int * count);
char ** parsePostPipe(char * s, int * count);
void standardCommand(char *);
void redirCommand(char * str);
void redirCommand2(char * str);
void saveToList(char* str, LinkedList* histList);

#endif
