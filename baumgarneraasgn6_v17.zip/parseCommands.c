#include "parseCommands.h"

//Left side of |
char ** parsePrePipe(char * s, int * count)
{
	char * saveptr;
	char * token;
	char ** this;
	char * temp = (char*)calloc((strlen(s)+1), sizeof(char));
	strcpy(temp, s);
	
	token = strtok_r(temp, "|", &saveptr);
	this = makeargs(token, count);
	free(temp);
	
	return this;
}


//right side of |
char ** parsePostPipe(char * s, int * count)
{
	char * saveptr;
	char * token;
	char ** this;
	char * temp = (char*)calloc((strlen(s)+1), sizeof(char));
	strcpy(temp, s);
	
	token = strtok_r(temp, "|", &saveptr);
	token = strtok_r(NULL, "|", &saveptr);	
	
	this = makeargs(token, count);
	free(temp);
	
	return this;
}

