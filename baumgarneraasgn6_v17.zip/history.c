#include "history.h"

extern int histCount;
extern int histFileCount;

History* histObj()
{
	History * theHist = (History *) malloc(sizeof(History));
	theHist -> histCount = 100;
	theHist -> histFileCount = 1000;
	
	return theHist;
}

void setCounts(FILE * fin, History* hist)
{
	char str[MAX];
	char * savePt;
	char * token;
	
	hist -> histCount = 100;
	hist -> histFileCount = 1000;
	
	if(fin != NULL)
	{
		fgets(str, MAX, fin);
		
		while(!feof(fin))
		{
			strip(str);
			
			if(strlen(str) != 0)
			{
				token = strtok_r(str, "=", &savePt);
				
				if(strcmp(token, "HISTCOUNT") == 0)
				{				
					token = strtok_r(NULL, "=", &savePt);
					hist -> histCount = atoi(token);
				}
				else if(strcmp(token, "HISTFILECOUNT") == 0)
				{
					token = strtok_r(NULL, "=", &savePt);
					hist -> histFileCount = atoi(token);
				}
			}
			fgets(str, MAX, fin);
		}	
	}
	rewind(fin);
}

void cleanHistory(History * hist)
{
	free(hist);
}
