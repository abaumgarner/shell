/*
 * Aaorn Baumgarner
 * 
 */

#include "alias.h"

void printAlias(void * passedIn, int i)
{
	Alias * temp = (Alias *)passedIn;
	
	printf("alias %s=%s\n", temp -> aliasName, temp -> aliasCMD);
}

int compareTwoAlias(const void * p1, const void * p2)
{
	Alias* alias1 = (Alias*)p1;
	Alias* alias2 = (Alias*) p2;
	return strcmp(alias1 -> aliasName, alias2 -> aliasName);
}

int compareTo(const void* p, char* str)
{
	Alias* ali = (Alias*)p;
	
	return strcmp(ali->aliasName, str);
}

void cleanAlias(void * ali)
{
	free(((Alias*)ali)->aliasName);
	free(((Alias*)ali)->aliasCMD);
	free((Alias*)ali);
}
void * buildAlias(FILE * fin)
{
	char str[MAX];
	char *result;
	Alias * ali = (Alias *)malloc(sizeof(Alias));
	char * token;
	char * save;
	
	fgets(str, MAX, fin);
	
	strip(str);

	token = strtok_r(str, "=", &save);
	result = (char *)malloc((strlen(token)+1) * sizeof(char));
	strncpy((char*) result, token, strlen(token));
	ali -> aliasName = result;
	
	token = strtok_r(NULL, "='", &save);
	
	result = (char *)malloc((strlen(token)+1) * sizeof(char));
	strncpy((char*) result, token, strlen(token));
	ali -> aliasCMD = result;
	
	return (void *)ali;
}
