#ifndef LINKEDLIST_H
#define LINKEDLIST_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>


struct node
{
    void * data;
    struct node * next;
    struct node * prev;
};
typedef struct node Node;


struct linkedlist
{
    Node * head;
    Node * tail;
    int size;
};
typedef struct linkedlist LinkedList;


LinkedList * linkedList();
Node * getAtIndex(LinkedList * theList, int index);
void buildList(LinkedList * myList, FILE * fin, int total, void * (*buildData)(FILE * in));

void addLast(LinkedList * theList, Node * nn);
void addFirst(LinkedList * theList, Node * nn);
void removeItem(LinkedList * theList, Node * nn, void (*removeData)(void *), int (*compare)(const void *, const void *));

void clearList(LinkedList * theList, void (*removeData)(void *));
void printList(const LinkedList * theList, void (*convertData)(void *, int));
void printListFromIndex(const LinkedList * theList, int until, void (*convertData)(void *, int));
void sort(LinkedList * theList, int (*compare)(const void *, const void *));
void saveToFile(LinkedList* histList, int histFileCount, FILE* fout, void (*convertData)(void *,FILE*));
Node* findNode(LinkedList* theList, char* str, int (*findData)(void* p,char* str));

#endif // LINKEDLIST_H
